// SPACE 3 ★ — THE NIGHTMARE (turning point)
// Board notes: in desperation the child steals food and the police are called. They run down the
// alleys as the world around them distorts into a nightmare. The police slowly turn into monsters,
// the buildings swirl and change, people yell "stop". As a child, they imagine the world the way
// they see it. Doing nothing: the creatures close in, the red thread pulses; being caught triggers
// a soft reset to the last checkpoint. The stolen food glows and grows heavy.
import * as THREE from 'three';
import * as T from '../textures.js';
import { M, TM, box, cyl, makeSack, lerp, ease, setMonster, animateFigure } from '../kit.js';
import { cityBlock, MARKET } from './street.js';

// walkable corridors (axis-aligned) in route order, and the corner points between them
export const ROUTE = [
  { x0: 40, x1: 54, z0: 7, z1: 9.6 },
  { x0: 51.4, x1: 54, z0: -6, z1: 9.6 },
  { x0: 51.4, x1: 68, z0: -6, z1: -3.4 },
  { x0: 65.4, x1: 68, z0: -6, z1: 14 },
  { x0: 65.4, x1: 82, z0: 11.4, z1: 14 },
];
const CORNERS = [new THREE.Vector3(52.7, 0, 8.3), new THREE.Vector3(52.7, 0, -4.7), new THREE.Vector3(66.7, 0, -4.7), new THREE.Vector3(66.7, 0, 12.7)];
export const HOME_DOOR = new THREE.Vector3(82, 1.2, 12.7);
const CHECKPOINTS = [
  { x: 41.2, z: 8.3, yaw: -Math.PI / 2 }, { x: 52.7, z: 6.5, yaw: 0 }, { x: 54.5, z: -4.7, yaw: -Math.PI / 2 },
  { x: 66.7, z: -3, yaw: Math.PI }, { x: 68.5, z: 12.7, yaw: -Math.PI / 2 },
];

export function buildNightmare(ctx) {
  const { scene, audio, player, ui, settings, debug, journey, guide, police, pursuit, thought } = ctx;
  const root = new THREE.Group(); root.name = 'nightmare'; scene.add(root);
  const bagCtl = journey.bagCtl;
  const colliders = [];
  const buildings = [];

  // ground along the whole route
  ROUTE.forEach(r => {
    const g = new THREE.Mesh(new THREE.PlaneGeometry(r.x1 - r.x0, r.z1 - r.z0), TM(T.dirtFloor([(r.x1 - r.x0) / 3, (r.z1 - r.z0) / 3])));
    g.rotation.x = -Math.PI / 2; g.position.set((r.x0 + r.x1) / 2, 0.003 + Math.random() * 0.001, (r.z0 + r.z1) / 2); root.add(g);
  });
  // blocks between the corridors (they also close off the east side of the market)
  const cols = ['#a89a80', '#9aa0a8', '#b09a90', '#a0a88a', '#a898a8', '#b0906a'];
  [[40, 54, 9.6, 20], [40, 51.4, -12, 7], [54, 65.4, -3.4, 20], [51.4, 82, -12, -6], [68, 82, -6, 11.4], [65.4, 82, 14, 20],
    [82, 92, -12, 10], [82, 92, 15.4, 22], [88, 92, 10, 15.4]].forEach(([a, b, c, d]) => {
    colliders.push(cityBlock(root, a, b, c, d, { colours: cols, hMin: 7, hMax: 13, night: true, glow: 0x1a1018, list: buildings }));
  });
  buildings.forEach((m, i) => { m.userData.ph = i * 1.7; });

  // obstacles: carts, crates and sacks you have to weave around
  const crateMat = TM(T.plywood());
  const obstacles = [
    [45, 7.6, 1.0, 0.8], [48.6, 9.05, 0.8, 0.8], [50.2, 7.75, 1.8, 0.9],
    [52.3, 4.5, 0.9, 0.9], [53.2, 0.2, 0.8, 0.8], [52.0, -2.4, 0.9, 0.9],
    [57, -5.35, 1.8, 0.9], [61, -4.05, 0.9, 0.9], [64, -5.3, 0.9, 0.8],
    [66.15, -0.8, 0.9, 0.9], [67.3, 3.5, 0.9, 0.9], [66.1, 8, 0.9, 0.9],
    [70.5, 12.05, 0.9, 0.9], [74.2, 13.35, 1.0, 0.8], [78, 12.1, 0.9, 0.9],
  ];
  obstacles.forEach(([x, z, w, d], i) => {
    if (i % 3 === 1) { const s = makeSack(M(0x5a5048, { flatShading: true }), 0.9); s.position.set(x, 0, z); root.add(s); }
    else { const h = 0.6 + (i % 2) * 0.4; const c = box(w, h, d, crateMat, x, h / 2, z, root); c.rotation.y = (Math.random() - 0.5) * 0.2; if (i % 4 === 0) box(w * 0.8, 0.5, d * 0.8, crateMat, x, h + 0.25, z, root); }
    colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });
  });

  // eyes in the windows (only seen once the nightmare takes hold)
  const EYES = 160, eg = new THREE.BufferGeometry(), ep = new Float32Array(EYES * 3);
  for (let i = 0; i < EYES; i++) {
    const r = ROUTE[i % ROUTE.length], horiz = (r.x1 - r.x0) > (r.z1 - r.z0);
    const side = Math.random() < 0.5;
    ep[i * 3] = horiz ? lerp(r.x0, r.x1, Math.random()) : (side ? r.x0 - 0.05 : r.x1 + 0.05);
    ep[i * 3 + 1] = 2 + Math.random() * 7;
    ep[i * 3 + 2] = horiz ? (side ? r.z0 - 0.05 : r.z1 + 0.05) : lerp(r.z0, r.z1, Math.random());
  }
  eg.setAttribute('position', new THREE.BufferAttribute(ep, 3));
  const eyeMat = new THREE.PointsMaterial({ size: 0.16, map: T.dot(), color: 0xff3a1a, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
  root.add(new THREE.Points(eg, eyeMat));

  // light: the glowing food in your bag lights the way; lightning now and then
  const bagLight = new THREE.PointLight(0xff9a40, 0, 9, 1.4); root.add(bagLight);
  const redLight = new THREE.PointLight(0xff2a1a, 0, 10, 1.5); root.add(redLight);  // follows the monsters

  root.traverse(o => { if (o.isMesh) { o.castShadow = false; o.receiveShadow = false; } });

  // ---------- sound ----------
  let sounds = [], snd = {};
  function startSounds() {
    audio.stopAll(sounds); sounds = [];
    const add = (k, a) => { snd[k] = a; sounds.push(a); return a; };
    add('drone', audio.loop('drone', { volume: 0 }));
    add('whispers', audio.loop('whispers', { volume: 0 }));
    add('heart', audio.loop('heartbeat', { volume: 0 }));
    add('yells', audio.loop('yells', { object: police[0], volume: 0.5, ref: 2, rate: 0.95 }));
    add('wind', audio.loop('wind', { volume: 0.3 }));
  }

  // ---------- story ----------
  const S = { phase: 'idle', t: 0, warp: 0, cp: 0, stamina: 1, tired: false, caughtT: 0, flash: 0, nextFlash: 4, ended: false, screamed: false };
  const head = new THREE.Vector3();
  function hint(text, secs = 5) { if (!player.inVR && settings.hints) ui.hint(text, secs); }
  function setPhase(p) { S.phase = p; S.t = 0; if (debug) debug.textContent = 'phase: ' + p; }

  function progress(x, z) { // which corridor are we in (highest index wins at corners)
    let best = 0; ROUTE.forEach((r, i) => { if (x >= r.x0 - 0.3 && x <= r.x1 + 0.3 && z >= r.z0 - 0.3 && z <= r.z1 + 0.3) best = i; });
    return best;
  }
  const routePoints = (h) => {
    const seg = progress(h.x, h.z);
    return [...CORNERS.slice(seg).map(c => new THREE.Vector3(c.x, 0.05, c.z)), HOME_DOOR];
  };

  function reset() {
    Object.assign(S, { phase: 'idle', t: 0, warp: 0, cp: 0, stamina: 1, tired: false, caughtT: 0, flash: 0, nextFlash: 4, ended: false, screamed: false });
    buildings.forEach(m => { m.rotation.set(0, 0, 0); m.scale.set(1, 1, 1); });
    police.forEach(p => setMonster(p, 0));
    eyeMat.opacity = 0; bagLight.intensity = 0; redLight.intensity = 0;
    player.speedScale = 1; player.canRun = true;
  }
  function start() {
    reset(); startSounds();
    setPhase('chase');
    pursuit.speed = 2.5;
    bagCtl.glow = 0.6;
    guide.set(routePoints);
    ui.subtitle('Police: "Ruko! Stop right there!"', 2.5);
  }
  function stop() { audio.stopAll(sounds); sounds = []; snd = {}; pursuit.stop(); bagLight.intensity = 0; redLight.intensity = 0; }

  function update(dt, t, active = true) {
    // the city breathes and leans once the nightmare starts
    if (S.warp > 0.001) {
      buildings.forEach(m => {
        const w = S.warp, ph = m.userData.ph;
        m.rotation.z = w * 0.07 * Math.sin(t * 0.6 + ph);
        m.rotation.x = w * 0.05 * Math.sin(t * 0.45 + ph * 1.3);
        m.scale.y = 1 + w * 0.18 * Math.sin(t * 0.9 + ph);
      });
    }
    if (S.phase === 'idle' || S.phase === 'done' || !active) return;
    S.t += dt;
    player.headWorld(head);

    // the nightmare grows over the first seconds
    S.warp = Math.min(1, S.warp + dt / 7);
    const mk = ease(Math.min(1, S.t / 6));
    police.forEach(p => { setMonster(p, mk); animateFigure(p, t, dt); });
    if (!S.screamed && S.t > 2.5) { S.screamed = true; audio.oneShot('scream', { object: police[0], volume: 0.7, ref: 3 }); thought('They\'re not men anymore.', 3.5); }
    if (S.t > 14 && S.t - dt <= 14) thought('The bag is so heavy. Don\'t drop it.', 3.5);
    if (S.t > 30 && S.t - dt <= 30) thought('Almost home. Almost home.', 3);
    eyeMat.opacity = S.warp * (0.6 + 0.4 * Math.sin(t * 2.3));
    bagCtl.glow = 0.6 + 0.4 * S.warp; bagCtl.heavy = Math.min(1, S.t / 40);
    bagLight.position.set(head.x, 0.8, head.z); bagLight.intensity = 2.5 + S.warp * 2 + Math.sin(t * 5) * 0.3;
    redLight.position.copy(police[0].position).setY(2.2); redLight.intensity = S.warp * 4;

    // running costs breath
    const moving = player.vel.length() > 0.5, running = player.running && moving;
    S.stamina = Math.min(1, Math.max(0, S.stamina + (running ? -dt / 6 : dt / 4)));
    if (S.stamina <= 0.01) S.tired = true;
    if (S.tired && S.stamina > 0.35) S.tired = false;
    player.canRun = !S.tired;
    player.speedScale = 1 - 0.12 * bagCtl.heavy;

    // pursuers: faster when you stand still
    pursuit.speed = 2.5 + (moving ? 0 : 0.6);
    const d = S.phase === 'chase' ? pursuit.update(dt) : 99;
    const near = Math.max(0, 1 - d / 10);
    if (snd.drone) snd.drone.setVolume(0.9 * S.warp);
    if (snd.whispers) snd.whispers.setVolume(0.5 * S.warp * (0.4 + near));
    if (snd.heart) { snd.heart.setVolume(0.3 + 0.7 * near); snd.heart.setPlaybackRate(1 + near * 0.9); }
    guide.urgent = !moving;

    // checkpoints
    const seg = progress(head.x, head.z);
    if (seg > S.cp) S.cp = seg;

    // lightning
    S.nextFlash -= dt;
    if (S.nextFlash <= 0) { S.nextFlash = 6 + Math.random() * 6; S.flash = 1; setTimeout(() => audio.oneShot('thunder', { volume: 0.6 }), 400 + Math.random() * 600); }
    S.flash = Math.max(0, S.flash - dt * 3);

    switch (S.phase) {
      case 'chase':
        if (d < 0.9) { setPhase('caught'); ui.fade(true); pursuit.stop(); audio.oneShot('scream', { volume: 0.5, rate: 1.2 }); }
        if (head.x > HOME_DOOR.x - 0.9 && head.z > 11.4 && !S.ended) { S.ended = true; pursuit.stop(); guide.clear(); setPhase('done'); onEndFn && onEndFn('home'); }
        break;
      case 'caught':
        if (S.t > 0.9 && S.t - dt <= 0.9) {
          const c = CHECKPOINTS[S.cp];
          player.place(c.x, c.z, c.yaw, player.eye);
          pursuit.active = true; pursuit.rewind(8);
          S.stamina = 1; S.tired = false;
        }
        if (S.t > 1.2) { ui.fade(false); setPhase('chase'); thought('No. Again. Run.', 2.5); }
        break;
    }
  }

  function atmosphere() {
    const w = S.warp, f = S.flash;
    return {
      fog: new THREE.Color(0xb08a60).lerp(new THREE.Color(0x2a0a12), Math.min(1, w * 1.4)).lerp(new THREE.Color(0x9a90c0), f * 0.5),
      density: lerp(0.03, 0.065, w), sun: lerp(1.6, 0, Math.min(1, w * 2)) + f * 2, hemi: lerp(0.8, 0.28, w) + f * 1.5,
      hemiSky: new THREE.Color(0xffe8c8).lerp(new THREE.Color(0x6a3a8a), w), hemiGround: new THREE.Color(0x3a2a1a).lerp(new THREE.Color(0x14060a), w),
    };
  }

  let onEndFn = null;
  return {
    root, update, start, stop, reset, atmosphere,
    zone: { minX: MARKET.x1 + 0.4, maxX: 82 },
    onEnd(fn) { onEndFn = fn; },
    getColliders() { return colliders; },
    get phase() { return S.phase; },
    get stamina() { return S.stamina; },
    skip() { if (S.phase === 'chase') player.place(81.5, 12.7, -Math.PI / 2, player.eye); },
  };
}
