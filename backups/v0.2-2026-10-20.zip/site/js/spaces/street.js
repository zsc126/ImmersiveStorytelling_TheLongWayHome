// SPACE 2 — THE STREET (entrance stub, v0.2)
// For now this is only the first stretch of alley outside the factory door, so Space 1
// has somewhere real to lead into. Space 2 proper (market stall, begging, the coin shortfall)
// continues further along +x — see WORLD.md for the layout plan.
// Look reference: Space 2 rough view — narrow lane, tall patched facades, tangled wires,
// cloth/tarp awnings, a bicycle against the wall, uneven ground.
import * as THREE from 'three';
import * as T from '../textures.js';
import { M, TM, box, cyl, wire, fabricMat, makeSack } from '../kit.js';

export const ALLEY = { x0: 8, x1: 27, z0: 2.4, z1: 5.4, walkTo: 13 };

export function buildAlley(parent) {
  const root = new THREE.Group(); root.name = 'alley'; parent.add(root);
  const { x0, x1, z0, z1 } = ALLEY;
  const zc = (z0 + z1) / 2, len = x1 - x0;
  const colliders = [];

  // ground: packed dirt, a drain along one side, puddles
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(len, z1 - z0 + 0.2), TM(T.dirtFloor([len / 3, 1])));
  ground.rotation.x = -Math.PI / 2; ground.position.set(x0 + len / 2, 0.002, zc); root.add(ground);
  box(len, 0.02, 0.25, M(0x14110d, { roughness: 0.3 }), x0 + len / 2, 0.004, z1 - 0.2, root);
  [[10.2, 3.5, 0.9], [14.5, 4.2, 1.3], [19, 3.2, 0.8]].forEach(([x, z, s]) => {
    const p = new THREE.Mesh(new THREE.CircleGeometry(0.5, 14), M(0x1a1612, { roughness: 0.05, metalness: 0.6 }));
    p.rotation.x = -Math.PI / 2; p.scale.set(s * 1.4, s, 1); p.position.set(x, 0.006, z); root.add(p);
  });

  // facades on both sides — uneven heights, each a different faded colour
  const colours = ['#b9a27f', '#8fa3a0', '#c29a8e', '#a9a17a', '#9aa0b4', '#b48c6a', '#a6b08e'];
  const glow = 0x2a1c12; // fake dusk bounce light so we don't leak real lights into the factory
  function building(xa, xb, side, h, i) {
    const depth = 4, w = xb - xa;
    const t = T.facade(colours[i % colours.length], [w / 4, h / 4]);
    const mat = new THREE.MeshStandardMaterial({ map: t, emissive: glow, emissiveMap: t, roughness: 0.95 });
    const zFace = side < 0 ? z0 : z1;
    const b = box(w, h, depth, mat, (xa + xb) / 2, h / 2, zFace + side * depth / 2, root);
    const face = zFace;            // the face toward the lane
    const out = -side;             // direction from face into the lane
    // windows: dark openings with grilles or shutters
    for (let y = 2.4; y < h - 0.8; y += 2.6) {
      for (let x = xa + 0.7; x < xb - 0.6; x += 1.6 + Math.random() * 0.5) {
        if (Math.random() < 0.25) continue;
        const win = box(0.75, 1.0, 0.05, M(0x0d0b09), x, y, face + out * 0.02, root);
        if (Math.random() < 0.35) { win.material = M(0xffc070, { emissive: 0xff9a40, emissiveIntensity: 0.6 }); }
        for (let k = 0; k < 4; k++) box(0.015, 1.0, 0.02, M(0x1a1a1a, { metalness: 0.6 }), x - 0.3 + k * 0.2, y, face + out * 0.06, root);
        if (Math.random() < 0.3) box(0.9, 0.12, 0.6, M(0x5a5a52), x, y - 0.6, face + out * 0.3, root); // ledge / balcony slab
        if (Math.random() < 0.2) box(0.55, 0.4, 0.45, M(0xb8b4a8, { roughness: 0.6 }), x + 0.6, y - 0.2, face + out * 0.25, root); // AC unit
      }
    }
    // ground-floor: shutter or doorway
    if (Math.random() < 0.6) box(Math.min(2, w - 0.6), 2.0, 0.05, TM(T.tin([2, 1]), { metalness: 0.4 }), (xa + xb) / 2, 1.0, face + out * 0.03, root);
    colliders.push({ minX: xa, maxX: xb, minZ: side < 0 ? z0 - depth : z1, maxZ: side < 0 ? z0 : z1 + depth });
    return b;
  }
  let x = x0, i = 0;
  while (x < x1) { const w = 2.5 + Math.random() * 2.5; building(x, Math.min(x1, x + w), -1, 6 + Math.random() * 5, i++); x += w; }
  x = x0; i = 3;
  while (x < x1) { const w = 2.5 + Math.random() * 2.5; building(x, Math.min(x1, x + w), 1, 6 + Math.random() * 5, i++); x += w; }

  // tarp & cloth awnings at the first-floor line
  [[9.5, -1, 0x2c5a9a], [12.8, 1, 0x8a3a2a], [16.2, -1, 0x2c5a9a], [20.5, 1, 0xa8862a]].forEach(([ax, side, col]) => {
    const aw = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.3), M(col, { side: THREE.DoubleSide, roughness: 1 }));
    aw.position.set(ax, 2.55, (side < 0 ? z0 : z1) - side * 0.55); aw.rotation.x = -Math.PI / 2 + side * 0.45; root.add(aw);
  });
  // tangled overhead wires crossing the lane
  const wm = M(0x0e0e0e);
  for (let k = 0; k < 26; k++) {
    const xa = x0 + Math.random() * len, xb = xa + (Math.random() - 0.5) * 4, y = 3.6 + Math.random() * 3.5;
    root.add(wire(new THREE.Vector3(xa, y, z0), new THREE.Vector3(xb, y + (Math.random() - 0.5), z1), 0.2 + Math.random() * 0.6, wm, 0.012));
  }
  for (let k = 0; k < 6; k++) { // a few running along the lane
    const z = z0 + 0.2 + Math.random() * (z1 - z0 - 0.4), y = 4 + Math.random() * 2;
    root.add(wire(new THREE.Vector3(x0, y, z), new THREE.Vector3(x0 + 6 + Math.random() * 8, y, z), 0.5, wm, 0.01));
  }
  // laundry
  for (let k = 0; k < 3; k++) {
    const lx = 10 + k * 4.5, y = 3.3 + k * 0.4;
    root.add(wire(new THREE.Vector3(lx, y, z0), new THREE.Vector3(lx + 0.5, y, z1), 0.25, wm, 0.008));
    for (let c = 0; c < 4; c++) {
      const h = 0.5 + Math.random() * 0.4;
      const cl = new THREE.Mesh(new THREE.PlaneGeometry(0.45, h), fabricMat(k * 4 + c, { side: THREE.DoubleSide }));
      cl.geometry.translate(0, -h / 2, 0); cl.position.set(lx + 0.1 + c * 0.12, y - 0.2, z0 + 0.5 + c * 0.6); cl.rotation.y = Math.PI / 2; root.add(cl);
    }
  }

  // bicycle leaning on the wall (from the sketch)
  const bike = new THREE.Group(); bike.position.set(11.6, 0, z1 - 0.25); bike.rotation.z = 0.12; root.add(bike);
  const steel = M(0x2a2a2a, { metalness: 0.6, roughness: 0.5 });
  [-0.5, 0.5].forEach(bx => { const w = new THREE.Mesh(new THREE.TorusGeometry(0.33, 0.02, 6, 20), steel); w.position.set(bx, 0.35, 0); bike.add(w); });
  const bar = (a, b) => { const v = b.clone().sub(a); const m = cyl(0.015, 0.015, v.length(), steel, 5, bike); m.position.copy(a).add(b).multiplyScalar(0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v.normalize()); };
  const V = (x, y) => new THREE.Vector3(x, y, 0);
  bar(V(-0.5, 0.35), V(0, 0.35)); bar(V(0, 0.35), V(0.35, 0.8)); bar(V(-0.5, 0.35), V(-0.15, 0.8)); bar(V(-0.15, 0.8), V(0.35, 0.8)); bar(V(0, 0.35), V(-0.15, 0.8)); bar(V(0.5, 0.35), V(0.38, 0.95));
  box(0.04, 0.02, 0.45, steel, 0.4, 0.97, 0, bike);
  colliders.push({ minX: 10.9, maxX: 12.3, minZ: z1 - 0.5, maxZ: z1 });
  // clutter
  const sack = makeSack(M(0xb0a080, { flatShading: true }), 0.8); sack.position.set(9.0, 0, z0 + 0.35); root.add(sack);
  const bucket = cyl(0.18, 0.14, 0.32, M(0x2a6a9a, { roughness: 0.5 }), 12, root); bucket.position.set(13.4, 0.16, z0 + 0.3);
  box(0.5, 0.35, 0.4, TM(T.cardboard()), 14.2, 0.18, z0 + 0.35, root);
  colliders.push({ minX: 8.6, maxX: 9.5, minZ: z0, maxZ: z0 + 0.75 });

  // sky strip and the warm end of the lane
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(len + 4, 8), new THREE.MeshBasicMaterial({ map: T.duskSky(), fog: false, toneMapped: false, side: THREE.DoubleSide }));
  sky.rotation.x = Math.PI / 2; sky.position.set(x0 + len / 2, 13, zc); root.add(sky);
  const endGlow = new THREE.Mesh(new THREE.PlaneGeometry(4, 10), new THREE.MeshBasicMaterial({ color: 0xe8b07a, fog: false, toneMapped: false }));
  endGlow.position.set(x1 + 0.5, 5, zc); endGlow.rotation.y = -Math.PI / 2; root.add(endGlow);
  // one bare bulb outside a doorway — lights kept short-range so they don't leak into the factory
  const bulbMesh = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffd08a, toneMapped: false }));
  bulbMesh.position.set(12.4, 2.9, z0 + 0.3); root.add(bulbMesh);
  const lamp = new THREE.PointLight(0xffb066, 6, 5, 1.6); lamp.position.set(12.4, 2.8, z0 + 0.5); root.add(lamp);
  const dusk = new THREE.PointLight(0xffc89a, 10, 7, 1.2); dusk.position.set(15.5, 5, zc); root.add(dusk);

  // invisible end of the walkable area for now (Space 2 continues past here)
  colliders.push({ minX: ALLEY.walkTo + 1.2, maxX: ALLEY.walkTo + 1.4, minZ: z0, maxZ: z1 });

  root.traverse(o => { if (o.isMesh) { o.castShadow = false; o.receiveShadow = true; } });
  return { root, colliders, update() {} };
}
