// THE LONG WAY HOME — entry point
// Title screen → headphones card → Space 1 (The Sweatshop) → end card.
// Same page works on desktop (mouse + WASD) and in a VR headset browser (WebXR).
import * as THREE from 'three';
import { settings } from './settings.js';
import { AudioEngine } from './audio.js';
import { Player } from './player.js';
import { Interactor } from './interact.js';
import { UI } from './ui.js';
import { makeBag } from './kit.js';
import { buildSweatshop } from './spaces/sweatshop.js';
import { buildAlley } from './spaces/street.js';

const DEBUG = new URLSearchParams(location.search).has('debug');
const $ = s => document.querySelector(s);
const ui = new UI({ onAction, onSettingsChange: applySettings });
addEventListener('error', e => ui.error('Error: ' + e.message));
addEventListener('unhandledrejection', e => DEBUG && ui.error('Error: ' + (e.reason && e.reason.message || e.reason)));

// ---------- renderer ----------
const canvas = $('#scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor');

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(settings.fov, innerWidth / innerHeight, 0.03, 60);
const cineCam = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.05, 60);
const listener = new THREE.AudioListener();
camera.add(listener);

const audio = new AudioEngine(listener);
const interactor = new Interactor(camera);
const player = new Player({ renderer, camera, scene, canvas, interactor, audio });
const debugEl = DEBUG ? $('#debug') : null;
// What the child carries from space to space. The bag is the key object (see WORLD.md).
const journey = { bag: makeBag({ ours: true }), coins: 0, hasBag: false };
const alley = buildAlley(scene);   // Space 2 entrance (built now so the door opens onto it)
const world = buildSweatshop({ scene, audio, interactor, player, ui, settings, debug: debugEl, journey, extraColliders: alley.colliders });

// ---------- state ----------
let mode = 'title'; // title | intro | play | paused | end
document.body.classList.remove('playing');

function setMode(m) {
  mode = m;
  document.body.classList.toggle('playing', m === 'play' || m === 'paused');
}

// ---------- settings ----------
function applySettings(key) {
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2) * settings.resolution);
  renderer.setSize(innerWidth, innerHeight, false);
  camera.fov = settings.fov; camera.updateProjectionMatrix();
  if (renderer.shadowMap.enabled !== settings.shadows) {
    renderer.shadowMap.enabled = settings.shadows;
    world.setShadows(settings.shadows);
    scene.traverse(o => { if (o.material) [].concat(o.material).forEach(m => { m.needsUpdate = true; }); });
  }
  world.setQuality(settings.quality);
  listener.setMasterVolume(settings.volume);
  if (!settings.showFps) ui.fps('');
  if (!settings.hints) ui.hint('');
}
applySettings();

function onResize() {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = cineCam.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix(); cineCam.updateProjectionMatrix();
}
addEventListener('resize', onResize);
onResize();

// ---------- VR availability ----------
if (!window.isSecureContext) ui.setVR('insecure');
else if (navigator.xr && navigator.xr.isSessionSupported) {
  navigator.xr.isSessionSupported('immersive-vr').then(ok => ui.setVR(ok ? 'yes' : 'no')).catch(() => ui.setVR('no'));
} else ui.setVR('no');

// ---------- flow ----------
async function onAction(a) {
  if (a === 'begin') return beginDesktop();
  if (a === 'vr') return beginVR();
  if (a === 'resume') { ui.closeAllPanels(); setMode('play'); player.lock(); return; }
  if (a === 'restart') return restart();
  if (a === 'quit') return quitToTitle();
}

async function beginDesktop() {
  ui.show('title', false);
  ui.show('intro', true);
  setMode('intro');
  const l1 = $('#intro-1'), l2 = $('#intro-2');
  l2.textContent = 'Preparing sound…';
  setTimeout(() => l1.classList.add('on'), 300);
  await audio.init();
  l2.textContent = 'Click anywhere to sit down.';
  l2.classList.add('on');
  $('#intro').addEventListener('click', sitDown, { once: true });
}

function sitDown() {
  ui.fade(true);
  ui.show('intro', false);
  player.lock();
  world.start();
  setMode('play');
  // sound first, picture second — the machine is what they hear first
  setTimeout(() => ui.fade(false), 1600);
  $('#intro-1').classList.remove('on'); $('#intro-2').classList.remove('on');
}

async function beginVR() {
  try {
    await audio.init();
    renderer.xr.setFramebufferScaleFactor(settings.resolution < 1 ? 0.85 : 1);
    const session = await navigator.xr.requestSession('immersive-vr', { optionalFeatures: ['local-floor', 'bounded-floor'] });
    await renderer.xr.setSession(session);
    session.addEventListener('end', onVREnd);
    ui.show('title', false);
    player.enterVR();
    world.start();
    player.dolly.rotation.y = 0;
    setMode('play');
  } catch (e) {
    ui.error('Could not start VR: ' + e.message);
  }
}

function onVREnd() {
  player.exitVR();
  if (mode === 'play') { setMode('paused'); ui.openPanel('pause'); }
}

player.onPauseRequest = () => {
  if (mode === 'play') { setMode('paused'); ui.openPanel('pause'); ui.hint(''); }
};

world.onEnd(() => {
  ui.fade(true, true);
  setTimeout(() => {
    setMode('end');
    player.unlock();
    const s = renderer.xr.getSession();
    if (s) s.end();
    world.stop();
    ui.show('endcard', true);
    ui.fade(false);
  }, 1600);
});

function restart() {
  ui.closeAllPanels();
  ui.show('endcard', false);
  ui.fade(true);
  setTimeout(() => {
    world.start();
    setMode('play');
    player.lock();
    ui.fade(false);
  }, 700);
}

function quitToTitle() {
  ui.closeAllPanels();
  ui.show('endcard', false);
  world.stop();
  world.reset();
  player.unlock();
  const s = renderer.xr.getSession(); if (s) s.end();
  setMode('title');
  ui.show('title', true);
}

// click back into the scene if pointer lock was lost without pausing
canvas.addEventListener('click', () => { if (mode === 'play' && !player.locked && !renderer.xr.isPresenting) player.lock(); });

if (DEBUG) {
  addEventListener('keydown', e => { if (e.code === 'KeyN') world.skip(); });
  window.__tlwh = { advance(sec) { for (let i = 0; i < sec / 0.05; i++) { elapsed += 0.05; world.update(0.05, elapsed, true); player.update(0.05); } }, world, player, scene, camera, renderer, begin: beginDesktop, sitDown, interactor };
}

// ---------- loop ----------
const clock = new THREE.Clock();
let last = 0, fpsAcc = 0, fpsN = 0, elapsed = 0;
renderer.setAnimationLoop((time) => {
  const xr = renderer.xr.isPresenting;
  if (!xr && settings.fpsCap > 0 && time - last < 1000 / settings.fpsCap - 1.5) return;
  last = time;
  const dt = Math.min(clock.getDelta(), 0.05);
  elapsed += dt;

  world.update(dt, elapsed, mode === 'play');

  if (mode === 'play') {
    player.update(dt);
    if (xr) player.updateControllers();
    else ui.crosshair(interactor.updateDesktop());
    interactor.updateHighlights(elapsed);
  }

  if (settings.showFps) {
    fpsAcc += dt; fpsN++;
    if (fpsAcc > 0.5) { ui.fps(Math.round(fpsN / fpsAcc) + ' fps'); fpsAcc = 0; fpsN = 0; }
  }

  if (mode === 'title' || mode === 'intro') {
    world.cine(cineCam, elapsed);
    renderer.render(scene, cineCam);
  } else {
    renderer.render(scene, camera);
  }
});
