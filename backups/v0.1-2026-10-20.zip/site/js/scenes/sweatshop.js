// SPACE 1 — THE SWEATSHOP
// Board notes this follows:
//  · gloomy, dimly lit, machines + quiet conversations; huge to a child but cramped and stuffy
//  · feed fabric through the machine, look out the one small window, receive the day's wages in coins
//  · glimpses of the school life the child could have had (window, daydream)
//  · key object: the faded, patched cloth bag hanging by the factory door
//  · wayfinding: a red thread / soft glow on one object at a time, no on-screen instructions needed
//  · doing nothing for 20 s: the world keeps going, the thread pulses harder
import * as THREE from 'three';
import * as T from '../textures.js';

const lerp = THREE.MathUtils.lerp, clamp = THREE.MathUtils.clamp;
const ease = x => x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;

// ---- layout (metres; furniture is ~1.35× real size so you feel like a child) ----
const ROOM = { minX: -8, maxX: 8, minZ: -6, maxZ: 6, h: 4.2 };
const ROWS = [1.25, -1.5, -4.25];
const COLS = [-6.2, -3.6, -1.0, 1.6];
const TX = COLS[0], TZ = ROWS[0];            // the player's table
const TABLE_H = 1.0;
const SEAT = { x: TX, z: TZ + 0.85 };
const WINDOW = { z0: 1.45, z1: 2.45, y0: 1.55, y1: 2.3 };
const DOOR = { x0: 3.4, x1: 4.8, h: 3.0 };
const QUOTA = 4;

function M(color, o = {}) { return new THREE.MeshStandardMaterial({ color, roughness: 0.88, metalness: 0, ...o }); }
function box(w, h, d, mat, x = 0, y = 0, z = 0, parent) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z);
  if (parent) parent.add(m); return m;
}
function cyl(rt, rb, h, mat, seg = 10, parent) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat); if (parent) parent.add(m); return m;
}

const FABRICS = [
  ['#c8402e', '#f0c05a', 0], ['#2f4a8a', '#e9e2cf', 1], ['#d9a21b', '#7a2a1c', 2],
  ['#b0306a', '#f2d7a0', 0], ['#2f7a5a', '#f0e0b0', 2], ['#e07b2a', '#3a2a5a', 1],
];
const fabricTex = FABRICS.map(f => T.fabric(...f));
const fabricMat = (i, o) => M(0xffffff, { map: fabricTex[i % fabricTex.length], ...o });

// ---------------------------------------------------------------------------------
function makeFigure({ skin = 0x6b4630, cloth = 0x6d6a5e, cloth2, hair = 0x16110d, scale = 1.25, standing = false, sari = false, bun = false }) {
  const g = new THREE.Group();
  const f = { flatShading: true, roughness: 0.92 };
  const mSkin = M(skin, f), mCloth = M(cloth, f), mCloth2 = M(cloth2 ?? cloth, f), mHair = M(hair, f);
  const hip = standing ? 0.9 : 0.5;
  if (standing) {
    [-0.08, 0.08].forEach(x => { const l = cyl(0.065, 0.055, 0.9, mCloth2, 6, g); l.position.set(x, 0.45, 0); });
  } else {
    [-0.085, 0.085].forEach(x => {
      box(0.13, 0.12, 0.42, sari ? mCloth2 : mCloth2, x, hip + 0.02, -0.17, g);
      const s = cyl(0.05, 0.045, 0.48, sari ? mCloth2 : mSkin, 6, g); s.position.set(x, hip - 0.22, -0.38);
    });
  }
  const torso = cyl(0.15, 0.18, 0.56, mCloth, 7, g); torso.position.y = hip + 0.3;
  if (sari) { const d = box(0.36, 0.62, 0.05, mCloth2, 0, hip + 0.32, -0.12, g); d.rotation.z = 0.55; d.rotation.x = -0.1; }
  const neck = cyl(0.05, 0.055, 0.1, mSkin, 6, g); neck.position.y = hip + 0.62;
  const head = new THREE.Group(); head.position.y = hip + 0.76; g.add(head);
  head.add(new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), mSkin));
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.128, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.55), mHair);
  cap.rotation.x = -0.25; head.add(cap);
  if (bun) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 5), mHair); b.position.set(0, 0.02, 0.12); head.add(b); }
  if (sari) { const veil = new THREE.Mesh(new THREE.SphereGeometry(0.135, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.5), mCloth2); veil.rotation.x = -0.6; head.add(veil); }
  const arms = [];
  [-1, 1].forEach(side => {
    const sh = new THREE.Group(); sh.position.set(side * 0.2, hip + 0.52, 0); g.add(sh);
    const up = cyl(0.048, 0.042, 0.3, mCloth, 6, sh); up.position.y = -0.15;
    const el = new THREE.Group(); el.position.y = -0.3; sh.add(el);
    const fo = cyl(0.04, 0.035, 0.27, mSkin, 6, el); fo.position.y = -0.135;
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.045, 6, 5), mSkin); hand.position.y = -0.29; el.add(hand);
    arms.push({ sh, el, hand });
  });
  g.scale.setScalar(scale);
  g.userData = { arms, head, phase: Math.random() * 10, speed: 5 + Math.random() * 2.5, work: 1, standing };
  return g;
}

function animateFigure(fig, t, dt) {
  const u = fig.userData;
  if (u.standing) {
    u.arms.forEach((a, i) => { a.sh.rotation.x = lerp(a.sh.rotation.x, u.reach && i === 1 ? 1.35 : 0.08 + 0.03 * Math.sin(t + i), dt * 3); a.el.rotation.x = lerp(a.el.rotation.x, u.reach && i === 1 ? 0.1 : 0.25, dt * 3); });
    u.head.rotation.y = lerp(u.head.rotation.y, u.look ?? 0, dt * 2);
    return;
  }
  const w = u.work;
  u.arms.forEach((a, i) => {
    const s = Math.sin(t * u.speed + u.phase + i * 2.2);
    a.sh.rotation.x = lerp(0.12, 0.55 + 0.16 * s, w);
    a.el.rotation.x = lerp(0.35, 0.9 + 0.14 * Math.sin(t * u.speed + u.phase + i * 2.2 + 1), w);
  });
  u.head.rotation.x = lerp(0.05, 0.32 + 0.03 * Math.sin(t * 0.7 + u.phase), w);
  u.head.rotation.y = 0.15 * Math.sin(t * 0.21 + u.phase) * (1.6 - w);
}

function makeMachine() {
  const g = new THREE.Group();
  const enamel = M(0x1a1a18, { roughness: 0.45, metalness: 0.35 });
  const gold = M(0x9a7a3a, { roughness: 0.4, metalness: 0.6 });
  const steel = M(0x9a9a98, { roughness: 0.3, metalness: 0.8 });
  box(0.64, 0.05, 0.32, enamel, 0, 0.025, 0, g);
  box(0.11, 0.27, 0.16, enamel, 0.24, 0.18, 0, g);
  box(0.58, 0.09, 0.13, enamel, -0.02, 0.33, 0, g);
  box(0.4, 0.008, 0.132, gold, -0.02, 0.376, 0, g);
  box(0.11, 0.21, 0.14, enamel, -0.26, 0.24, 0, g);
  const needle = cyl(0.006, 0.006, 0.13, steel, 5, g); needle.position.set(-0.26, 0.12, 0.02);
  const foot = box(0.04, 0.01, 0.06, steel, -0.26, 0.058, 0.02, g);
  const wheel = cyl(0.075, 0.075, 0.03, M(0x2a2a28, { metalness: 0.5, roughness: 0.4 }), 14, g);
  wheel.rotation.z = Math.PI / 2; wheel.position.set(0.32, 0.3, 0);
  const spool = cyl(0.025, 0.025, 0.05, M(0xd23a2c), 8, g); spool.position.set(0.05, 0.4, 0);
  g.userData = { needle, wheel, foot, speed: 0 };
  return g;
}
function animateMachine(m, t, dt) {
  const u = m.userData;
  u.ph = (u.ph || 0) + dt * u.speed * 14 * Math.PI * 2;
  u.needle.position.y = 0.12 + 0.025 * Math.sin(u.ph);
  u.wheel.rotation.x += dt * u.speed * 18;
}

function makeTable(parent, x, z, withStool = true) {
  const g = new THREE.Group(); g.position.set(x, 0, z); parent.add(g);
  const top = M(0xffffff, { map: T.wood([1, 1], '#5d4029') });
  const dark = M(0x2b2219);
  box(1.7, 0.05, 0.9, top, 0, TABLE_H - 0.025, 0, g);
  [[-0.8, -0.4], [0.8, -0.4], [-0.8, 0.4], [0.8, 0.4]].forEach(([a, b]) => box(0.06, TABLE_H - 0.05, 0.06, dark, a, (TABLE_H - 0.05) / 2, b, g));
  box(1.6, 0.03, 0.8, dark, 0, 0.25, 0, g);
  if (withStool) {
    const s = new THREE.Group(); s.position.set(0, 0, 0.72); g.add(s);
    const seat = cyl(0.21, 0.21, 0.05, M(0x4a3524), 10, s); seat.position.y = 0.6;
    for (let k = 0; k < 3; k++) { const l = cyl(0.02, 0.02, 0.6, dark, 5, s); const a = k * 2.1; l.position.set(Math.cos(a) * 0.15, 0.3, Math.sin(a) * 0.15); l.rotation.set(Math.sin(a) * 0.12, 0, -Math.cos(a) * 0.12); }
  }
  return g;
}

function makeBag({ base = 0x4b5f86, patches = [0xc9933a, 0x9a3b2a], ours = false }) {
  const g = new THREE.Group();
  const cloth = M(base, { flatShading: true, roughness: 1, side: THREE.DoubleSide });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.155, 0.3, 9, 1, true), cloth);
  g.add(body);
  const bottom = new THREE.Mesh(new THREE.CircleGeometry(0.155, 9), cloth); bottom.rotation.x = Math.PI / 2; bottom.position.y = -0.15; g.add(bottom);
  patches.forEach((c, i) => {
    const p = box(0.08, 0.07, 0.01, M(c, { roughness: 1 }), 0, -0.04 + i * 0.09, 0.145, g);
    p.rotation.y = (i - 0.5) * 0.9; p.position.x = Math.sin(p.rotation.y) * 0.14; p.position.z = Math.cos(p.rotation.y) * 0.14;
  });
  const strap = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.012, 5, 14, Math.PI), M(0x6a5a44, { roughness: 1 }));
  strap.position.y = 0.15; g.add(strap);
  // flap that closes the top
  const flapPivot = new THREE.Group(); flapPivot.position.set(0, 0.15, -0.13); g.add(flapPivot);
  const flap = new THREE.Mesh(new THREE.CircleGeometry(0.135, 9), cloth); flap.rotation.x = -Math.PI / 2; flap.position.z = 0.13; flapPivot.add(flap);
  g.userData = { flapPivot, open: 0 };
  if (ours) {
    const inside = new THREE.Group(); inside.position.y = 0.05; g.add(inside);
    const pencil = new THREE.Group();
    const pb = cyl(0.008, 0.008, 0.07, M(0xe0b83a), 6, pencil); pb.rotation.z = Math.PI / 2;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.018, 6), M(0x3a2a1a)); tip.rotation.z = -Math.PI / 2; tip.position.x = 0.044; pencil.add(tip);
    pencil.position.set(0.03, 0.07, 0.04); pencil.rotation.y = 0.5; inside.add(pencil);
    const page = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.15), new THREE.MeshStandardMaterial({ map: T.notebookPage(), roughness: 1, side: THREE.DoubleSide }));
    page.rotation.set(-1.1, 0.2, 0.15); page.position.set(-0.03, 0.06, -0.02); inside.add(page);
    const coins = [];
    for (let i = 0; i < 3; i++) {
      const c = cyl(0.022, 0.022, 0.006, M(0xb8913a, { metalness: 0.8, roughness: 0.35 }), 12, inside);
      c.position.set(-0.05 + i * 0.045, 0.065 + i * 0.004, 0.05 - i * 0.02); c.rotation.x = 0.4; c.visible = false; coins.push(c);
    }
    inside.visible = false;
    Object.assign(g.userData, { inside, coins, page, pencil });
  }
  return g;
}

function setBagOpen(bag, k) {
  const u = bag.userData; u.open = k;
  u.flapPivot.rotation.x = -k * 2.2;
  if (u.inside) { u.inside.visible = k > 0.15; u.inside.position.y = 0.04 + 0.05 * k; }
}

// =================================================================================
export function buildSweatshop({ scene, audio, interactor, player, ui, settings, renderer, debug }) {
  const root = new THREE.Group(); root.name = 'sweatshop'; scene.add(root);
  scene.background = new THREE.Color(0x0c0a08);
  scene.fog = new THREE.FogExp2(0x1d1712, 0.05);

  // ---------- shell ----------
  const W = ROOM.maxX - ROOM.minX, D = ROOM.maxZ - ROOM.minZ;
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), M(0xffffff, { map: T.concrete([4, 3]) }));
  floor.rotation.x = -Math.PI / 2; root.add(floor);
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(W, D), M(0xffffff, { map: T.ceiling([8, 1]), side: THREE.DoubleSide }));
  ceil.rotation.x = Math.PI / 2; ceil.position.y = ROOM.h; root.add(ceil);

  const wallTex = T.wall([1, 1]);
  function wallPiece(w, h, x, y, z, ry) {
    const t = wallTex.clone(); t.needsUpdate = true; t.repeat.set(w / 4, h / ROOM.h); t.offset.set(x * 0.13, (y - h / 2) / ROOM.h);
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), M(0xffffff, { map: t }));
    m.position.set(x, y, z); m.rotation.y = ry; root.add(m); return m;
  }
  // front (−z) and right (+x)
  wallPiece(W, ROOM.h, 0, ROOM.h / 2, ROOM.minZ, 0);
  wallPiece(D, ROOM.h, ROOM.maxX, ROOM.h / 2, 0, -Math.PI / 2);
  // left wall with the small window
  const lw = (z0, z1, y0, y1) => wallPiece(z1 - z0, y1 - y0, ROOM.minX, (y0 + y1) / 2, (z0 + z1) / 2, Math.PI / 2);
  lw(ROOM.minZ, ROOM.maxZ, 0, WINDOW.y0); lw(ROOM.minZ, ROOM.maxZ, WINDOW.y1, ROOM.h);
  lw(ROOM.minZ, WINDOW.z0, WINDOW.y0, WINDOW.y1); lw(WINDOW.z1, ROOM.maxZ, WINDOW.y0, WINDOW.y1);
  // back wall (+z) with the door
  const bw = (x0, x1, y0, y1) => wallPiece(x1 - x0, y1 - y0, (x0 + x1) / 2, (y0 + y1) / 2, ROOM.maxZ, Math.PI);
  bw(ROOM.minX, DOOR.x0, 0, ROOM.h); bw(DOOR.x1, ROOM.maxX, 0, ROOM.h); bw(DOOR.x0, DOOR.x1, DOOR.h, ROOM.h);

  // beams, pipes, wires
  const beamMat = M(0x2a241d);
  for (let x = -6; x <= 6; x += 4) box(0.25, 0.3, D, beamMat, x, ROOM.h - 0.15, 0, root);
  const pipe = cyl(0.05, 0.05, W, M(0x5a4a3a, { metalness: 0.5, roughness: 0.6 }), 8, root); pipe.rotation.z = Math.PI / 2; pipe.position.set(0, 3.7, 5.5);

  // ---------- window (small, barred, high) ----------
  const winFrame = M(0x3a3026);
  const wx = ROOM.minX, wzc = (WINDOW.z0 + WINDOW.z1) / 2, wyc = (WINDOW.y0 + WINDOW.y1) / 2;
  box(0.18, 0.06, WINDOW.z1 - WINDOW.z0 + 0.12, winFrame, wx + 0.02, WINDOW.y0 - 0.03, wzc, root);
  box(0.18, 0.06, WINDOW.z1 - WINDOW.z0 + 0.12, winFrame, wx + 0.02, WINDOW.y1 + 0.03, wzc, root);
  box(0.18, WINDOW.y1 - WINDOW.y0, 0.06, winFrame, wx + 0.02, wyc, WINDOW.z0 - 0.03, root);
  box(0.18, WINDOW.y1 - WINDOW.y0, 0.06, winFrame, wx + 0.02, wyc, WINDOW.z1 + 0.03, root);
  for (let k = 1; k <= 4; k++) { const b = cyl(0.012, 0.012, WINDOW.y1 - WINDOW.y0, M(0x222020, { metalness: 0.6, roughness: 0.5 }), 6, root); b.position.set(wx, wyc, WINDOW.z0 + k * (WINDOW.z1 - WINDOW.z0) / 5); }
  // the world outside
  const outside = new THREE.Group(); root.add(outside);
  const yard = new THREE.Mesh(new THREE.PlaneGeometry(9, 6.75), new THREE.MeshBasicMaterial({ map: T.schoolyard(), toneMapped: false, fog: false }));
  yard.position.set(wx - 3.2, 2.5, wzc); yard.rotation.y = Math.PI / 2; outside.add(yard);
  const kids = [];
  const kidTex = [T.schoolchild(), T.schoolchild('#f4f0e6', '#7a2f3a'), T.schoolchild('#eef3f8', '#2f4f8f')];
  for (let i = 0; i < 6; i++) {
    const k = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.84), new THREE.MeshBasicMaterial({ map: kidTex[i % 3], transparent: true, toneMapped: false, fog: false, alphaTest: 0.1 }));
    k.rotation.y = Math.PI / 2; k.position.set(wx - 2.4 - Math.random() * 0.5, 0.95 + Math.random() * 0.25, wzc - 2 + Math.random() * 4);
    k.userData = { speed: 0.25 + Math.random() * 0.5, dir: Math.random() < 0.5 ? 1 : -1, ph: Math.random() * 6 };
    outside.add(k); kids.push(k);
  }
  const windowSound = new THREE.Object3D(); windowSound.position.set(wx, wyc, wzc); root.add(windowSound);
  const windowDef = interactor.add(new THREE.Mesh(new THREE.PlaneGeometry(WINDOW.z1 - WINDOW.z0, WINDOW.y1 - WINDOW.y0), new THREE.MeshBasicMaterial({ visible: false })), { label: 'Look outside' });
  windowDef.object.position.set(wx + 0.05, wyc, wzc); windowDef.object.rotation.y = Math.PI / 2; root.add(windowDef.object);
  windowDef.meshes.forEach(m => { m.material.visible = false; }); // gaze target only

  // daylight through the window
  const sun = new THREE.SpotLight(0xffe2b0, 55, 14, 0.42, 0.7, 1.4);
  sun.position.set(wx - 2.5, 3.6, wzc + 0.2);
  sun.target.position.set(TX + 0.6, TABLE_H - 0.2, wzc - 0.2);
  root.add(sun, sun.target);
  sun.shadow.mapSize.set(1024, 1024); sun.shadow.bias = -0.002;
  const shaftMat = new THREE.MeshBasicMaterial({ map: T.shaftGradient(), transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
  const shaftFrom = new THREE.Vector3(wx, wyc, wzc), shaftTo = new THREE.Vector3(TX + 1.2, 0.0, wzc - 0.5);
  const shaftLen = shaftFrom.distanceTo(shaftTo);
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 1.1, shaftLen, 16, 1, true), shaftMat);
  shaft.position.copy(shaftFrom).add(shaftTo).multiplyScalar(0.5);
  shaft.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), shaftFrom.clone().sub(shaftTo).normalize());
  root.add(shaft);

  // ---------- lights ----------
  const hemi = new THREE.HemisphereLight(0x8a7458, 0x1a140f, 0.55); root.add(hemi);
  const bulbs = [];
  const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffd08a, toneMapped: false });
  function bulb(x, z, intensity, withLight = true) {
    const wire = cyl(0.006, 0.006, ROOM.h - 3.0, M(0x111111), 4, root); wire.position.set(x, (ROOM.h + 3.0) / 2, z);
    const shade = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.14, 12, 1, true), M(0x3f4a3a, { side: THREE.DoubleSide, metalness: 0.4, roughness: 0.6 }));
    shade.position.set(x, 3.02, z); root.add(shade);
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), bulbMat.clone()); b.position.set(x, 2.93, z); root.add(b);
    let light = null;
    if (withLight) { light = new THREE.PointLight(0xffb066, intensity, 9, 1.6); light.position.set(x, 2.85, z); root.add(light); }
    bulbs.push({ b, light, base: intensity, flick: Math.random() * 10 });
  }
  bulb(TX + 0.2, TZ - 0.1, 9);          // over the player's table
  bulb(-3.6, -1.5, 7); bulb(1.6, -4.25, 6); bulb(-1.0, 1.25, 6);
  bulb(-1.0, -4.25, 0, false); bulb(1.6, 1.25, 0, false); bulb(-3.6, -4.25, 0, false);
  const deskLight = new THREE.PointLight(0xdff2ff, 5, 6, 1.6); deskLight.position.set(6.0, 2.6, 3.0); root.add(deskLight);
  const tube = box(0.06, 0.04, 1.2, new THREE.MeshBasicMaterial({ color: 0xe8f6ff, toneMapped: false }), 6.0, 2.75, 3.0, root);

  // ---------- furniture & people ----------
  const colliders = [];
  const machines = [];
  const figures = [];
  const skins = [0x6b4630, 0x7a5236, 0x5a3a26, 0x845a3c, 0x4e3322];
  const outfits = [
    { cloth: 0x7a2f3a, cloth2: 0x9a4a3a, sari: true, bun: true }, { cloth: 0x5a6a5e }, { cloth: 0x3f5f6a, cloth2: 0x2f4f5a, sari: true, bun: true },
    { cloth: 0x8a7a5a }, { cloth: 0x6a3f5a, cloth2: 0xa86a2a, sari: true }, { cloth: 0x4a4a52 },
  ];
  const childSeats = new Set(['0,1', '1,2', '2,0']);
  ROWS.forEach((z, r) => COLS.forEach((x, c) => {
    const isPlayer = r === 0 && c === 0;
    makeTable(root, x, z, true);
    const m = makeMachine(); m.position.set(x, TABLE_H, z - 0.05); root.add(m);
    machines.push({ m, isPlayer });
    if (isPlayer) { colliders.push({ minX: x - 0.88, maxX: x + 0.88, minZ: z - 0.48, maxZ: z + 0.48 }); return; }
    colliders.push({ minX: x - 0.88, maxX: x + 0.88, minZ: z - 0.48, maxZ: z + 1.0 });
    m.userData.speed = 1;
    // fabric heaps on other tables
    for (let k = 0; k < 3; k++) box(0.34, 0.03, 0.26, fabricMat(r + c + k), x - 0.55, TABLE_H + 0.015 + k * 0.03, z + 0.1, root).rotation.y = Math.random() * 0.3;
    for (let k = 0; k < 2 + ((r + c) % 3); k++) box(0.3, 0.025, 0.22, fabricMat(r * 2 + c + k + 3), x + 0.55, TABLE_H + 0.012 + k * 0.025, z + 0.1, root);
    const child = childSeats.has(`${r},${c}`);
    const o = outfits[(r * 4 + c) % outfits.length];
    const scale = child ? 0.95 : 1.25;
    const fig = makeFigure({ ...o, skin: skins[(r + c * 2) % skins.length], scale, sari: o.sari && !child, bun: o.bun && !child, cloth: child ? 0x8a8070 : o.cloth });
    fig.position.set(x, 0.625 - 0.5 * scale, z + 0.72);
    root.add(fig); figures.push(fig);
  }));

  // the player's own table: piles of uncut and finished fabric
  const leftPile = new THREE.Group(); leftPile.position.set(TX - 0.55, TABLE_H, TZ + 0.12); root.add(leftPile);
  const pileLayers = [];
  for (let k = 0; k < 7; k++) { const l = box(0.34, 0.016, 0.26, fabricMat(k), 0, 0.008 + k * 0.016, 0, leftPile); l.rotation.y = (Math.random() - 0.5) * 0.25; pileLayers.push(l); }
  const pileDef = interactor.add(leftPile, { label: 'Take the fabric' });
  const rightPile = new THREE.Group(); rightPile.position.set(TX + 0.55, TABLE_H, TZ + 0.12); root.add(rightPile);
  const playerMachine = machines.find(m => m.isPlayer).m;
  const machineDef = interactor.add(playerMachine, { label: 'Hold to sew' });
  const machineSoundObj = new THREE.Object3D(); machineSoundObj.position.set(TX - 0.2, TABLE_H + 0.2, TZ); root.add(machineSoundObj);
  // the piece currently being sewn
  const piece = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.006, 0.4), fabricMat(0, { side: THREE.DoubleSide }));
  piece.visible = false; root.add(piece);
  const NEEDLE = new THREE.Vector3(TX - 0.26, TABLE_H + 0.054, TZ - 0.03);

  // ---------- clothes lines, fans, sacks, shelf ----------
  const lineMat = M(0x2a2420);
  const cloths = [];
  [0.1, -2.9].forEach((z, li) => {
    const l = cyl(0.006, 0.006, W - 1, lineMat, 4, root); l.rotation.z = Math.PI / 2; l.position.set(0, 3.45, z);
    for (let x = -7; x < 7; x += 0.75 + Math.random() * 0.4) {
      if (Math.random() < 0.25) continue;
      const h = 0.6 + Math.random() * 0.5;
      const cl = new THREE.Mesh(new THREE.PlaneGeometry(0.55, h), fabricMat(li * 7 + Math.floor(x * 3 + 30), { side: THREE.DoubleSide }));
      cl.geometry.translate(0, -h / 2, 0);
      cl.position.set(x, 3.45, z); root.add(cl); cloths.push(cl);
    }
  });
  const fans = [];
  [[-3.6, 0], [1.6, -3]].forEach(([x, z]) => {
    const f = new THREE.Group(); f.position.set(x, 4.0, z); root.add(f);
    cyl(0.02, 0.02, 0.2, M(0x222222), 5, f).position.y = 0.1;
    cyl(0.08, 0.08, 0.06, M(0x3a3a36, { metalness: 0.5 }), 10, f);
    for (let k = 0; k < 3; k++) { const b = box(0.7, 0.01, 0.12, M(0x4a4a42, { metalness: 0.3 }), 0, -0.02, 0); b.position.x = 0; b.geometry.translate(0.38, 0, 0); b.rotation.y = k * Math.PI * 2 / 3; f.add(b); }
    fans.push(f);
  });
  // bales and heaps (front-right)
  for (let i = 0; i < 9; i++) {
    const b = box(1.0, 0.6, 0.8, fabricMat(i), 4.6 + (i % 3) * 1.05, 0.3 + Math.floor(i / 3) * 0.6, -5.2, root);
    b.rotation.y = (Math.random() - 0.5) * 0.15;
  }
  [[5.0, -3.0, 1.1], [6.6, -2.4, 0.9], [4.4, -1.9, 0.7]].forEach(([x, z, s], i) => {
    const geo = new THREE.IcosahedronGeometry(1, 3);
    const p = geo.attributes.position;
    for (let k = 0; k < p.count; k++) {
      const vx = p.getX(k), vy = p.getY(k), vz = p.getZ(k);
      const d = 1 + 0.14 * Math.sin(vx * 5 + i) * Math.cos(vz * 4) + 0.08 * Math.sin(vy * 7);
      p.setXYZ(k, vx * d, Math.max(vy, -0.2) * d, vz * d);
    }
    geo.computeVertexNormals();
    const h = new THREE.Mesh(geo, fabricMat(i + 2)); h.scale.set(s, s * 0.55, s); h.position.set(x, 0.1, z); root.add(h);
  });
  colliders.push({ minX: 3.7, maxX: 8, minZ: -6, maxZ: -1.1 });
  // spools shelf (right wall)
  const shelf = new THREE.Group(); shelf.position.set(7.75, 0, 0.6); root.add(shelf);
  for (let y = 0.6; y <= 2.2; y += 0.55) {
    box(0.4, 0.04, 2.0, M(0x4a3524), 0, y, 0, shelf);
    for (let k = 0; k < 9; k++) { const s = cyl(0.05, 0.05, 0.12, M(new THREE.Color().setHSL(Math.random(), 0.6, 0.45)), 8, shelf); s.position.set(-0.05, y + 0.08, -0.9 + k * 0.22); }
  }
  colliders.push({ minX: 7.4, maxX: 8, minZ: -0.5, maxZ: 1.7 });
  // wall details: quota board, clock
  const quota = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.8), M(0xffffff, { map: T.quotaBoard() }));
  quota.position.set(-2.3, 2.7, ROOM.minZ + 0.02); root.add(quota);
  const clock = new THREE.Group(); clock.position.set(0.4, 2.9, ROOM.minZ + 0.03); root.add(clock);
  clock.add(new THREE.Mesh(new THREE.CircleGeometry(0.28, 24), M(0xffffff, { map: T.clockFace() })));
  const hHand = box(0.02, 0.14, 0.01, M(0x1a1612), 0, 0.07, 0.01, clock); hHand.geometry.translate(0, 0.0, 0); hHand.position.set(0, 0, 0.01); hHand.geometry.translate(0, 0.07, 0);
  const mHand = box(0.014, 0.21, 0.01, M(0x1a1612), 0, 0, 0.015, clock); mHand.geometry.translate(0, 0.105, 0);
  hHand.rotation.z = -Math.PI * 2 * (6.6 / 12);

  // ---------- supervisor's desk ----------
  const desk = new THREE.Group(); desk.position.set(6.0, 0, 3.0); root.add(desk);
  box(0.85, 1.15, 1.9, M(0xffffff, { map: T.wood([1, 1], '#4a3220') }), 0, 0.575, 0, desk);
  const ledger = box(0.32, 0.04, 0.42, M(0x6a1f1f), -0.1, 1.17, -0.3, desk);
  const tin = cyl(0.09, 0.09, 0.08, M(0x6d7570, { metalness: 0.7, roughness: 0.4 }), 12, desk); tin.position.set(-0.15, 1.19, 0.35);
  const foreman = makeFigure({ standing: true, scale: 1.35, cloth: 0xd8d2c0, cloth2: 0x3a3a40, skin: 0x7a5236 });
  foreman.position.set(6.85, 0, 3.0); foreman.rotation.y = Math.PI / 2; root.add(foreman);
  colliders.push({ minX: 5.5, maxX: 7.5, minZ: 1.95, maxZ: 4.05 });
  const foremanDef = interactor.add(foreman, { label: 'Collect your wages' });
  // the desk ledger also counts as "the supervisor"
  ledger.material = ledger.material.clone(); ledger.userData.owner = foremanDef; ledger.userData.baseEmissive = ledger.material.emissive.clone();
  foremanDef.meshes.push(ledger);

  // ---------- door ----------
  const doorPivot = new THREE.Group(); doorPivot.position.set(DOOR.x0, 0, ROOM.maxZ - 0.03); root.add(doorPivot);
  const doorPanel = box(DOOR.x1 - DOOR.x0, DOOR.h, 0.06, M(0xffffff, { map: T.metal([1, 2], '#35546a'), metalness: 0.3, roughness: 0.7 }), (DOOR.x1 - DOOR.x0) / 2, DOOR.h / 2, 0, doorPivot);
  box(0.04, 0.2, 0.06, M(0x8a8a80, { metalness: 0.8 }), DOOR.x1 - DOOR.x0 - 0.15, 1.4, -0.05, doorPivot);
  const doorDef = interactor.add(doorPivot, { label: 'Go outside' });
  const glow = new THREE.Mesh(new THREE.PlaneGeometry(12, 8), new THREE.MeshBasicMaterial({ color: 0xffe9c2, toneMapped: false, fog: false }));
  glow.position.set(4.1, 3, ROOM.maxZ + 2.5); glow.rotation.y = Math.PI; root.add(glow);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(6, 4), M(0xc9a46a)); ground.rotation.x = -Math.PI / 2; ground.position.set(4.1, 0, ROOM.maxZ + 2); root.add(ground);
  const doorLight = new THREE.PointLight(0xffe2b0, 0, 12, 1.2); doorLight.position.set(4.1, 2.2, ROOM.maxZ - 0.6); root.add(doorLight);
  const doorSound = new THREE.Object3D(); doorSound.position.set(4.1, 1.5, ROOM.maxZ); root.add(doorSound);

  // ---------- bags by the door ----------
  const hookMat = M(0x2a2a28, { metalness: 0.7, roughness: 0.4 });
  const hooks = [5.25, 5.8, 6.35, 6.9];
  hooks.forEach(x => box(0.03, 0.03, 0.08, hookMat, x, 1.62, ROOM.maxZ - 0.05, root));
  [[0x6a5a40, [0x3a5a7a]], [0x7a3a2a, [0xd0b070]], [0x4a5a3a, []]].forEach(([b, p], i) => {
    const o = makeBag({ base: b, patches: p }); o.position.set(hooks[i + 1], 1.62 - 0.32, ROOM.maxZ - 0.17); o.rotation.y = Math.PI + (Math.random() - 0.5) * 0.4; root.add(o); setBagOpen(o, 0);
  });
  const bag = makeBag({ ours: true });
  const BAG_HOME = new THREE.Vector3(hooks[0], 1.62 - 0.32, ROOM.maxZ - 0.17);
  const bagDef = interactor.add(bag, { label: 'Take your bag' });
  // keep the bag's own inside objects un-highlighted but allowed

  // ---------- daydream (a glimpse of school) ----------
  const dream = new THREE.Group(); dream.position.set(TX, 0, TZ); root.add(dream);
  const dreamMats = [];
  const dm = (o) => { const m = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false, fog: false, ...o }); dreamMats.push(m); return m; };
  const board = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 1.06), dm({ map: T.chalkboard() })); board.position.set(0, 2.0, -1.25); dream.add(board);
  const book = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.24), dm({ map: T.notebookPage(), side: THREE.DoubleSide })); book.rotation.x = -Math.PI / 2 + 0.25; book.position.set(0.0, TABLE_H + 0.02, 0.3); dream.add(book);
  const dreamLight = new THREE.PointLight(0xfff0c8, 0, 4, 1.5); dreamLight.position.set(0, 1.9, 0.2); dream.add(dreamLight);
  dream.visible = false;

  // ---------- dust ----------
  const DUST = 700;
  const dustGeo = new THREE.BufferGeometry();
  const dp = new Float32Array(DUST * 3);
  for (let i = 0; i < DUST; i++) { dp[i * 3] = lerp(ROOM.minX, ROOM.maxX, Math.random()); dp[i * 3 + 1] = Math.random() * 3.6; dp[i * 3 + 2] = lerp(ROOM.minZ, ROOM.maxZ, Math.random()); }
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dp, 3));
  const dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({ size: 0.025, map: T.dot(), transparent: true, opacity: 0.55, color: 0xffd9a0, blending: THREE.AdditiveBlending, depthWrite: false }));
  root.add(dust);

  // ---------- red thread (wayfinding) ----------
  const threadMat = new THREE.MeshBasicMaterial({ color: 0xd23a2c, transparent: true, opacity: 0.85, toneMapped: false });
  const thread = new THREE.Mesh(new THREE.BufferGeometry(), threadMat); thread.visible = false; root.add(thread);
  let threadTimer = 0;
  const headPos = new THREE.Vector3(), tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();
  function rebuildThread(target) {
    player.headWorld(headPos);
    const start = new THREE.Vector3(headPos.x, 0.9, headPos.z);
    player.camera.getWorldDirection(tmp); tmp.y = 0; tmp.normalize();
    start.addScaledVector(tmp, 0.45);
    const end = target.clone();
    const a = start.clone().lerp(end, 0.25); a.y = 0.06;
    const b = start.clone().lerp(end, 0.75); b.y = 0.06;
    const curve = new THREE.CatmullRomCurve3([start, a, b, end]);
    thread.geometry.dispose();
    thread.geometry = new THREE.TubeGeometry(curve, 40, 0.009, 5, false);
  }

  // shadows on/off
  root.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  [shaft, glow, yard, thread, ...kids].forEach(o => { o.castShadow = false; o.receiveShadow = false; });

  // =================================================================================
  // SOUND
  let sounds = [], snd = {};
  function startSounds() {
    audio.stopAll(sounds); sounds = [];
    const add = (k, a) => { snd[k] = a; sounds.push(a); return a; };
    add('room', audio.loop('room', { volume: 0.35 }));
    add('machine', audio.loop('sewing', { object: machineSoundObj, volume: 0, ref: 0.8 }));
    add('idle', audio.loop('hum', { object: machineSoundObj, volume: 0.15, ref: 0.8 }));
    const facts = [[-3.6, -1.5], [1.6, -1.5], [-1.0, 1.25], [1.6, -4.25]];
    snd.factory = facts.map(([x, z], i) => { const o = new THREE.Object3D(); o.position.set(x, 1.3, z); root.add(o); return add('f' + i, audio.loop('factory', { object: o, volume: 0.9, rate: 0.92 + i * 0.05, ref: 1.8 })); });
    snd.chatter = [[-3.6, -0.5], [1.6, -3.4]].map(([x, z], i) => { const o = new THREE.Object3D(); o.position.set(x, 1.6, z); root.add(o); return add('c' + i, audio.loop('chatter', { object: o, volume: 0.45, ref: 1.5 })); });
    fans.forEach((f, i) => add('fan' + i, audio.loop('hum', { object: f, volume: 0.25, rate: 0.7, ref: 1.2 })));
    add('children', audio.loop('children', { object: windowSound, volume: 0.35, ref: 1.0 }));
    add('street', audio.loop('street', { object: doorSound, volume: 0.06, ref: 1.5 }));
  }
  function stopSounds() { audio.stopAll(sounds); sounds = []; snd = {}; }

  // =================================================================================
  // STORY
  const S = {
    phase: 'idle', t: 0, pieces: 0, progress: 0, pushing: false, idle: 0, anim: null,
    factoryWork: 1, bagHeld: false, bagForceOpen: 0, coinsIn: 0, schoolBellT: 18, gaze: 0, standT: 0,
  };
  const flying = [];

  function hint(text, secs = 5) { if (!player.inVR && settings.hints) ui.hint(text, secs); }
  function setPhase(p) { S.phase = p; S.t = 0; S.idle = 0; interactor.urgency = 1; if (debug) debug.textContent = 'phase: ' + p; }

  pileDef.enabled = () => S.phase === 'pick';
  pileDef.onPress = () => {
    if (S.phase !== 'pick') return;
    const top = pileLayers[pileLayers.length - 1 - S.pieces];
    if (top) top.visible = false;
    piece.material.map = fabricTex[(pileLayers.length - 1 - S.pieces) % fabricTex.length];
    piece.visible = true;
    S.anim = { from: leftPile.localToWorld(new THREE.Vector3(0, 0.2, 0)), to: NEEDLE.clone().add(new THREE.Vector3(0, 0, 0.2)), t: 0, dur: 0.45 };
    audio.oneShot('fabric', { object: machineSoundObj, volume: 0.7 });
    S.progress = 0;
    setPhase('placing');
  };
  machineDef.enabled = () => S.phase === 'push';
  machineDef.onPress = () => { if (S.phase === 'push') S.pushing = true; };
  machineDef.onRelease = () => { S.pushing = false; };
  bagDef.enabled = () => S.phase === 'toBag';
  bagDef.onPress = () => {
    if (S.phase !== 'toBag') return;
    S.bagHeld = true;
    attachBag();
    audio.oneShot('fabric', { object: bag, volume: 0.6, rate: 0.8 });
    setPhase('toWages');
    interactor.active = foremanDef;
    hint('Find the supervisor at his desk', 5);
  };
  foremanDef.enabled = () => S.phase === 'toWages';
  foremanDef.onPress = () => {
    if (S.phase !== 'toWages') return;
    setPhase('paying');
    interactor.active = null;
    foreman.userData.reach = true;
  };
  doorDef.enabled = () => S.phase === 'toDoor';
  doorDef.onPress = () => {
    if (S.phase !== 'toDoor') return;
    setPhase('leaving');
    interactor.active = null;
    audio.oneShot('door', { object: doorSound, volume: 1 });
  };

  function attachBag() {
    if (player.inVR) {
      const hand = player.bagHand();
      hand.add(bag); bag.position.set(0, -0.2, 0.03); bag.rotation.set(0, 0, 0); bag.scale.setScalar(0.85);
    } else {
      player.camera.add(bag); bag.position.set(-0.26, -0.34, -0.55); bag.rotation.set(0.2, 0.4, 0); bag.scale.setScalar(0.5);
    }
  }
  function homeBag() {
    root.add(bag); bag.position.copy(BAG_HOME); bag.rotation.set(0, Math.PI, 0); bag.scale.setScalar(1);
    bag.userData.coins.forEach(c => { c.visible = false; }); setBagOpen(bag, 0);
  }

  function reset() {
    flying.forEach(f => root.remove(f.mesh)); flying.length = 0;
    S.pieces = 0; S.progress = 0; S.pushing = false; S.factoryWork = 1; S.bagHeld = false; S.bagForceOpen = 0; S.coinsIn = 0; S.anim = null;
    pileLayers.forEach(l => { l.visible = true; });
    rightPile.clear();
    piece.visible = false;
    homeBag();
    doorPivot.rotation.y = 0; doorLight.intensity = 0;
    foreman.userData.reach = false; foreman.userData.look = 0;
    figures.forEach(f => { f.userData.work = 1; });
    machines.forEach(({ m, isPlayer }) => { m.userData.speed = isPlayer ? 0 : 1; });
    dream.visible = false; dreamMats.forEach(m => { m.opacity = 0; }); dreamLight.intensity = 0;
    thread.visible = false;
    interactor.active = null;
    player.canMove = false;
    player.colliders = colliders;
    player.bounds = { minX: ROOM.minX, maxX: ROOM.maxX, minZ: ROOM.minZ, maxZ: ROOM.maxZ };
    setPhase('idle');
  }

  function start() {
    reset();
    player.place(SEAT.x, SEAT.z, 0, 1.3);
    startSounds();
    setPhase('intro');
  }

  function stop() { stopSounds(); thread.visible = false; setPhase('idle'); }

  // pay out the coins one by one
  function dropCoin(i) {
    const c = cyl(0.022, 0.022, 0.006, M(0xb8913a, { metalness: 0.8, roughness: 0.35 }), 12, root);
    const hand = foreman.userData.arms[1].hand;
    c.position.copy(hand.getWorldPosition(tmp));
    flying.push({ mesh: c, from: c.position.clone(), t: 0, dur: 0.75, i });
  }

  // ---------- per-frame ----------
  function update(dt, t, active = true) {
    // ambient life (runs on the title screen too)
    figures.forEach(f => { f.userData.work = lerp(f.userData.work, S.factoryWork, dt * 1.5); animateFigure(f, t, dt); });
    animateFigure(foreman, t, dt);
    machines.forEach(({ m, isPlayer }) => { if (!isPlayer) m.userData.speed = lerp(m.userData.speed, S.factoryWork, dt * 1.5); animateMachine(m, t, dt); });
    fans.forEach(f => { f.rotation.y += dt * 2.2; });
    cloths.forEach((c, i) => { c.rotation.x = 0.06 * Math.sin(t * 0.8 + i); });
    kids.forEach(k => {
      const u = k.userData; k.position.z += u.dir * u.speed * dt;
      if (k.position.z > wzc + 2.2 || k.position.z < wzc - 2.2) u.dir *= -1;
      k.position.y = 0.95 + Math.abs(Math.sin(t * 6 * u.speed + u.ph)) * 0.05;
    });
    bulbs.forEach(b => { if (!b.light) return; const f = 1 + 0.06 * Math.sin(t * 13 + b.flick) * Math.sin(t * 3.1 + b.flick); b.light.intensity = b.base * f; });
    deskLight.intensity = 5 * (Math.sin(t * 47) > 0.97 ? 0.4 : 1);
    mHand.rotation.z = -t * 0.02; hHand.rotation.z = -Math.PI * 2 * (6.6 / 12) - t * 0.0017;
    if (dust.visible) {
      const p = dust.geometry.attributes.position;
      for (let i = 0; i < DUST; i++) {
        let y = p.getY(i) + dt * 0.03; if (y > 3.6) y = 0;
        p.setY(i, y); p.setX(i, p.getX(i) + Math.sin(t * 0.3 + i) * dt * 0.02);
      }
      p.needsUpdate = true;
    }

    if (S.phase === 'idle' || !active) return;
    S.t += dt;
    S.idle += dt;
    interactor.urgency = S.idle > 20 ? 2.4 : 1;
    if (S.idle > 20 && S.idle - dt <= 20) remindIdle();

    // the window: looking out turns up the schoolyard
    player.headWorld(headPos);
    player.camera.getWorldDirection(tmp);
    tmp2.set(wx, wyc, wzc).sub(headPos).normalize();
    const looking = tmp.dot(tmp2) > 0.9 && headPos.distanceTo(tmp2.set(wx, wyc, wzc)) < 4;
    S.gaze = lerp(S.gaze, looking ? 1 : 0, dt * 1.5);
    S.schoolBellT -= dt;
    if (S.schoolBellT < 0 && S.phase !== 'leaving') { S.schoolBellT = 30 + Math.random() * 15; audio.oneShot('schoolBell', { object: windowSound, volume: 0.25 + S.gaze * 0.4 }); }

    // own machine
    const pm = playerMachine.userData;
    pm.speed = lerp(pm.speed, S.pushing && S.phase === 'push' ? 1 : 0, dt * 8);
    if (snd.machine) snd.machine.setVolume(pm.speed * 1.1 * (1 - 0.6 * (S.dreamK || 0)));
    if (snd.children) snd.children.setVolume(0.3 + 0.9 * Math.max(S.gaze, S.dreamK || 0));
    if (snd.factory) snd.factory.forEach(a => a.setVolume(0.9 * S.factoryWork * (1 - 0.6 * (S.dreamK || 0)) + 0.02));
    if (snd.chatter) snd.chatter.forEach(a => a.setVolume(0.45 + (1 - S.factoryWork) * 0.5));
    sun.intensity = 55 * (1 + 1.4 * (S.windowGlow || 0) + 0.3 * S.gaze);
    shaftMat.opacity = 0.22 * (1 + 1.2 * (S.windowGlow || 0));

    switch (S.phase) {
      case 'intro':
        if (S.t > 2.5) { setPhase('pick'); interactor.active = pileDef; hint('Look around with the mouse · click the fabric on your left', 6); }
        break;
      case 'placing': {
        const a = S.anim; a.t += dt / a.dur; const k = ease(Math.min(1, a.t));
        piece.position.lerpVectors(a.from, a.to, k); piece.position.y += Math.sin(k * Math.PI) * 0.12;
        piece.rotation.set(0, (1 - k) * 0.6, 0);
        if (a.t >= 1) { setPhase('push'); interactor.active = machineDef; if (S.pieces === 0) hint('Hold the mouse button on the machine to push the fabric through', 6); }
        break;
      }
      case 'push':
        if (S.pushing) { S.progress += dt / 3.2; S.idle = 0; }
        piece.position.set(NEEDLE.x, NEEDLE.y, NEEDLE.z + 0.2 - S.progress * 0.4);
        piece.position.x += Math.sin(S.progress * 30) * 0.004 * (S.pushing ? 1 : 0);
        if (S.progress >= 1) {
          audio.oneShot('fabric', { object: machineSoundObj, volume: 0.7, rate: 1.2 });
          S.anim = { from: piece.position.clone(), to: rightPile.localToWorld(new THREE.Vector3(0, 0.02 + S.pieces * 0.024, 0)), t: 0, dur: 0.5 };
          S.pushing = false; interactor.active = null;
          setPhase('folding');
        }
        break;
      case 'folding': {
        const a = S.anim; a.t += dt / a.dur; const k = ease(Math.min(1, a.t));
        piece.position.lerpVectors(a.from, a.to, k); piece.position.y += Math.sin(k * Math.PI) * 0.15;
        piece.scale.set(1, 1, 1 - 0.4 * k);
        if (a.t >= 1) {
          piece.visible = false; piece.scale.set(1, 1, 1);
          const folded = box(0.32, 0.024, 0.24, new THREE.MeshStandardMaterial({ map: piece.material.map, roughness: 0.9 }), 0, 0.012 + S.pieces * 0.024, 0, rightPile);
          folded.rotation.y = (Math.random() - 0.5) * 0.2;
          S.pieces++;
          if (S.pieces === 2) startDream('school');
          else if (S.pieces === 3) startDream('window');
          else if (S.pieces >= QUOTA) { setPhase('shiftEnd'); audio.oneShot('shiftBell', { volume: 0.55 }); }
          else { setPhase('pick'); interactor.active = pileDef; }
        }
        break;
      }
      case 'dream': {
        const d = S.dream; const k = S.t < 1.2 ? S.t / 1.2 : S.t > 4.2 ? Math.max(0, 1 - (S.t - 4.2) / 1.3) : 1;
        S.dreamK = d === 'school' ? k : k * 0.4;
        if (d === 'school') { dream.visible = true; dreamMats.forEach(m => { m.opacity = k * 0.85; }); dreamLight.intensity = k * 4; }
        else S.windowGlow = k;
        if (S.t > 5.5) { dream.visible = false; S.dreamK = 0; S.windowGlow = 0; setPhase('pick'); interactor.active = pileDef; }
        break;
      }
      case 'shiftEnd':
        S.factoryWork = Math.max(0, 1 - S.t / 2.5);
        if (S.t > 2.8) { setPhase('standing'); }
        break;
      case 'standing': {
        const k = ease(Math.min(1, S.t / 1.6));
        if (!player.inVR) { player.eye = lerp(1.3, 1.52, k); player.dolly.position.z = lerp(SEAT.z, SEAT.z + 0.75, k); }
        else if (S.t < dt * 1.5) player.dolly.position.z += 0.6;
        if (S.t > 1.7) {
          player.canMove = true;
          setPhase('toBag'); interactor.active = bagDef; thread.visible = true;
          hint(player.inVR ? '' : 'W A S D to walk · follow the red thread to your bag', 7);
        }
        break;
      }
      case 'paying':
        if (S.t > 0.6 && S.coinsIn + flying.length < 3 && S.t > 0.6 + (S.coinsIn + flying.length) * 0.7) dropCoin(S.coinsIn + flying.length);
        S.bagForceOpen = 1;
        if (S.coinsIn >= 3 && S.t > 3.6) {
          foreman.userData.reach = false; S.bagForceOpen = 0;
          setPhase('toDoor'); interactor.active = doorDef;
          hint(player.inVR ? '' : 'Hold Q to look inside your bag · then go home', 7);
        }
        break;
      case 'leaving': {
        const k = ease(Math.min(1, S.t / 1.4));
        doorPivot.rotation.y = k * 1.45;
        doorLight.intensity = k * 30;
        if (snd.street) snd.street.setVolume(0.06 + k * 0.9);
        if (S.t > 2.2 && !S.ended) { S.ended = true; ctx_onEnd && ctx_onEnd(); }
        break;
      }
    }

    // coins in flight
    for (let i = flying.length - 1; i >= 0; i--) {
      const f = flying[i]; f.t += dt / f.dur;
      const to = bag.getWorldPosition(tmp).add(tmp2.set(0, 0.12, 0));
      f.mesh.position.lerpVectors(f.from, to, ease(Math.min(1, f.t)));
      f.mesh.position.y += Math.sin(Math.min(1, f.t) * Math.PI) * 0.25;
      f.mesh.rotation.x += dt * 12;
      if (f.t >= 1) {
        root.remove(f.mesh); flying.splice(i, 1);
        bag.userData.coins[S.coinsIn].visible = true; S.coinsIn++;
        audio.oneShot('coin', { object: bag, volume: 0.9, rate: 0.95 + Math.random() * 0.1 });
      }
    }

    // supervisor turns to watch you once you're up
    if (['toBag', 'toWages', 'paying', 'toDoor'].includes(S.phase)) {
      const dx = headPos.x - foreman.position.x, dz = headPos.z - foreman.position.z;
      foreman.userData.look = clamp(Math.atan2(-dx, -dz) - foreman.rotation.y, -0.9, 0.9);
    }

    // bag: open when Q is held / when raised to the chest in VR / while being paid
    if (S.bagHeld) {
      let want = S.bagForceOpen;
      if (player.inVR) {
        bag.getWorldPosition(tmp);
        const near = tmp.distanceTo(headPos) < 0.6 && tmp.y > headPos.y - 0.6;
        if (near) want = 1;
      } else {
        if (player.bagHeld) want = 1;
        const k = Math.max(want, 0);
        const o = bag.userData.open;
        bag.position.set(lerp(-0.26, 0.0, o), lerp(-0.34, -0.24, o), lerp(-0.55, -0.45, o));
        bag.rotation.set(lerp(0.2, 0.95, o), lerp(0.4, 0, o), 0);
        want = k;
      }
      setBagOpen(bag, lerp(bag.userData.open, want, dt * 6));
    }

    // thread to the current goal
    if (thread.visible) {
      threadTimer -= dt;
      const goal = S.phase === 'toBag' ? BAG_HOME : S.phase === 'toWages' ? tmp2.set(5.55, 1.2, 3.0) : S.phase === 'toDoor' ? tmp2.set(4.1, 1.2, ROOM.maxZ - 0.1) : null;
      if (!goal) thread.visible = S.phase === 'paying';
      else if (threadTimer <= 0) { threadTimer = 0.08; rebuildThread(goal.clone ? goal.clone() : goal); }
      threadMat.opacity = (0.55 + 0.35 * Math.sin(t * 4)) * (S.idle > 20 ? 1 : 0.8);
      if (S.phase === 'leaving') thread.visible = false;
    }
  }

  function startDream(kind) {
    S.dream = kind;
    setPhase('dream');
    audio.oneShot('schoolBell', { object: kind === 'school' ? machineSoundObj : windowSound, volume: kind === 'school' ? 0.45 : 0.6 });
  }

  function remindIdle() {
    const m = {
      pick: 'Click the fabric on your left', push: 'Hold the mouse button on the machine',
      toBag: 'Follow the red thread to your bag by the door', toWages: 'Click the supervisor at his desk', toDoor: 'Click the door to go outside',
    }[S.phase];
    if (m) hint(m, 5);
  }

  // ---------- cinematic camera for the title screen ----------
  function cine(cam, t) {
    const k = 0.5 - 0.5 * Math.cos(t * Math.PI * 2 / 80);
    const x = lerp(-6.6, 2.6, k);
    cam.position.set(x, 1.18 + 0.03 * Math.sin(t * 0.5), 0.12);
    cam.lookAt(x + 2.5, 1.32, 0.12 + 1.6 * Math.sin(t * 0.09) + 0.6);
  }

  function setQuality(q) { dust.visible = q === 'high'; shaft.visible = q === 'high'; }
  function setShadows(on) { sun.castShadow = on; }

  let ctx_onEnd = null;
  return {
    root, update, start, stop, reset, cine, setQuality, setShadows,
    onEnd(fn) { ctx_onEnd = fn; },
    get phase() { return S.phase; },
    // debug helper: jump forward one step
    skip() {
      const p = S.phase;
      if (p === 'intro') S.t = 99;
      else if (p === 'pick') pileDef.onPress();
      else if (p === 'push') S.progress = 1;
      else if (p === 'dream') S.t = 99;
      else if (p === 'toBag') { player.place(BAG_HOME.x - 0.8, BAG_HOME.z - 0.9, Math.atan2(-0.8, -0.9), 1.52); bagDef.onPress(); }
      else if (p === 'toWages') { player.place(5.0, 3.0, -Math.PI / 2, 1.52); foremanDef.onPress(); }
      else if (p === 'toDoor') { player.place(4.1, 4.9, Math.PI, 1.52); doorDef.onPress(); }
      else if (p === 'shiftEnd' || p === 'standing' || p === 'paying') S.t = 99;
    },
  };
}
